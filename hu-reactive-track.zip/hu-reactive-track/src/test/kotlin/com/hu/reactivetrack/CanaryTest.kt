package com.hu.reactivetrack

import io.kotest.matchers.shouldBe
import io.mockk.mockk
import org.junit.jupiter.api.Test
import reactor.core.publisher.Flux
import reactor.test.StepVerifier

class CanaryTest {
    val mock = mockk<ReactiveTrackApplication>()

    @Test
    fun `testing the dependencies set-up`() {
        val fluxEvents = Flux.just("Hello", "World", "!")

        true shouldBe true

        StepVerifier.create(fluxEvents)
            .expectNext("Hello")
            .expectNext("World")
            .expectNext("!")
            .verifyComplete()
    }
}