package com.hu.reactivetrack

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ReactiveTrackApplicationTests {

	@Test
	fun contextLoads() {
	}

}
