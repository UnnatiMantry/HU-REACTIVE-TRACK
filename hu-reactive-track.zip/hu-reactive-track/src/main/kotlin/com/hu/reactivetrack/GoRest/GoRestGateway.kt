package com.hu.reactivetrack.GoRest

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.kotlin.registerKotlinModule
import com.hu.reactivetrack.GoRestResponse
import org.springframework.http.MediaType
import reactor.core.publisher.Mono
import com.hu.reactivetrack.controllers.GoRestController
import com.hu.reactivetrack.exceptions.BadDataException
import com.hu.reactivetrack.models.Comment
import com.hu.reactivetrack.models.Post
import com.hu.reactivetrack.models.User
import com.hu.reactivetrack.models.wrappers.CommentRequest
import com.hu.reactivetrack.models.wrappers.CreateUser
import com.hu.reactivetrack.models.wrappers.PostRequest
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import org.springframework.web.reactive.function.client.WebClient

@Component
class GoRestGateway (webClientBuilder: WebClient.Builder) {

    private val log: Logger = LoggerFactory.getLogger(GoRestController::class.java)

    private final val webClient: WebClient = webClientBuilder.baseUrl("https://gorest.co.in").build()
    private final val objectMapper = ObjectMapper().registerKotlinModule()

    fun createUser(userRequest : CreateUser):Mono<User>{
        return webClient.post().uri("/public-api/users")
            .headers { h -> h.setBearerAuth("d778db2a02d4878ac1dcd43223d65e4655a8c5069d305ed1b53165e8c3e8e7d3") }
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(userRequest), User::class.java)
            .retrieve().bodyToMono(GoRestResponse::class.java)
            .flatMap {
                if(it.code >=200 && it.code<=299){
                    Mono.just(objectMapper.convertValue(it.data,User::class.java))
                }else{
                    println("Error $it")
                    Mono.error(BadDataException(it.code,it.data))
                }
            }
    }

    fun createPost(postRequest: PostRequest):Mono<Post>{
        return webClient.post().uri("/public-api/posts")
            .headers { h -> h.setBearerAuth("2c268da0a289ac754e66d57abcc04754defd5c1b3008958f02dffbcfee959486") }
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(postRequest), User::class.java)
            .retrieve().bodyToMono(GoRestResponse::class.java)
            .flatMap {
                if(it.code >=200 && it.code<=299){
                    Mono.just(objectMapper.convertValue(it.data, Post::class.java))
                }else{
                    println("Error $it")
                    Mono.error(BadDataException(it.code,it.data))
                }
            }
    }

    fun createComment(commentRequest: CommentRequest):Mono<Comment>{
        return webClient.post().uri("/public-api/comments")
            .headers { h -> h.setBearerAuth("2c268da0a289ac754e66d57abcc04754defd5c1b3008958f02dffbcfee959486") }
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(commentRequest), User::class.java)
            .retrieve().bodyToMono(GoRestResponse::class.java)
            .flatMap {
                if(it.code >=200 && it.code<=299){
                    Mono.just(objectMapper.convertValue(it.data, Comment::class.java))
                }else{
                    println("Error $it")
                    Mono.error(BadDataException(it.code,it.data))
                }
            }
    }
}