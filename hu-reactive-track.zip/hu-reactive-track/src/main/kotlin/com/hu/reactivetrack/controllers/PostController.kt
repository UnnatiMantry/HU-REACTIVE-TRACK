package com.hu.reactivetrack.controllers

import com.hu.reactivetrack.models.Post
import com.hu.reactivetrack.models.wrappers.PostRequest
import com.hu.reactivetrack.service.PostService
import org.springframework.web.bind.annotation.*
import org.springframework.web.bind.annotation.RestController
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono

@RestController
class PostController  (val postService: PostService){

    @PostMapping("/main/post")
    fun createUser(@RequestBody postRequest: PostRequest): Mono<Post> {
        return postService.createPost(postRequest)
    }

    @GetMapping("/main/allCommentsOnPost/{postid}")
    fun getAllCommentsOnPost(@PathVariable postid : Int) : Flux<Any> {
        return postService.getAllCommentsOnPost(postid)
    }

}
