package com.hu.reactivetrack.models.wrappers

import com.hu.reactivetrack.models.User

data class CreateUserResponse(val code:Int,
                              val meta:Any?,
                              val data: User)
