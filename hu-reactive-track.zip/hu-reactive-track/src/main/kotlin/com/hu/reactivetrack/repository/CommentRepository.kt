package com.hu.reactivetrack.repository

import com.hu.reactivetrack.models.Comment
import org.springframework.data.mongodb.repository.Query
import org.springframework.data.mongodb.repository.ReactiveMongoRepository
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono

interface commentRepository : ReactiveMongoRepository<Comment, String> {
    fun findByemail(email: Mono<String>): Flux<Comment>
    @Query("{ 'post_id': ?0}")
    fun findAllCommentByPostId(postid:Int):Flux<Comment>

}