package com.hu.reactivetrack.exceptions

class UserNotFoundException(message: String?) : Exception(message)