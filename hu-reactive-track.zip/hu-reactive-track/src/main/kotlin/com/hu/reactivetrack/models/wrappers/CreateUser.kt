package com.hu.reactivetrack.models.wrappers

data class CreateUser(val name:String,
                      val gender:String,
                      val email:String,
                      val status:String)
