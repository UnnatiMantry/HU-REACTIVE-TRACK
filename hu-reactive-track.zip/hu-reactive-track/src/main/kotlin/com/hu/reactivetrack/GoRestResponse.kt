package com.hu.reactivetrack

data class GoRestResponse( val code : Int , val meta : Any? = null, val data : Any)

data class GoRestErrorResponse (
            val statusCode : Int,
            val errors : Any
)