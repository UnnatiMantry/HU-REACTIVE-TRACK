package com.hu.reactivetrack.models

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.index.Indexed
import org.springframework.data.mongodb.core.mapping.Document
import java.util.*

@Document("users")
data class User(@Id
                val id: Int,
                val name: String,
                val gender: String,

//              Users should have a unique identifier- email.
                @Indexed(unique = true)
                val email: String,

                val status: String,
                val created_at : Date,
                val updated_at : Date)

