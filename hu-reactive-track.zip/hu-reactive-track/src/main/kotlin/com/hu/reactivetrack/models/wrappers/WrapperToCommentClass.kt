package com.hu.reactivetrack.models.wrappers

import com.hu.reactivetrack.models.Comment


data class WrapperToCommentClass(val code:Int,
                                 val meta:Any,
                                 val data:ArrayList<Comment>
                                 )
