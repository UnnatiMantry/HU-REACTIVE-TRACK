package com.hu.reactivetrack.exceptions

import java.lang.RuntimeException

class BadDataException (
    val statusCode : Int,
    val errors : Any
) : RuntimeException()