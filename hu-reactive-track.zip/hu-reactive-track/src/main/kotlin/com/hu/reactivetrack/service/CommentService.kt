package com.hu.reactivetrack.service

import com.hu.reactivetrack.GoRest.GoRestGateway
import com.hu.reactivetrack.models.Comment
import com.hu.reactivetrack.models.wrappers.CommentRequest
import com.hu.reactivetrack.repository.commentRepository
import org.springframework.stereotype.Service
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono

@Service
class CommentService(val commentRepository: commentRepository, val goRestGateway: GoRestGateway){

    fun createComment(commentRequest: CommentRequest): Mono<Comment> {
        return goRestGateway.createComment(commentRequest)
            .flatMap { commentRepository.save(it) }
    }

    fun getCommentByEmail(email : String) : Flux<Comment> {
        return commentRepository.findByemail(Mono.just(email))
    }
}