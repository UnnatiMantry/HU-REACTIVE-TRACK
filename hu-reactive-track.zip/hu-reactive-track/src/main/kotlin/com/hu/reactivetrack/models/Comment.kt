package com.hu.reactivetrack.models

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document
import java.util.*

@Document("comments")
data class Comment(@Id
                   val id: Int,
                   val post_id:Int,
                   val name:String,
                   val email: String,
                   val body: String,
                   val created_at: Date,
                   val updated_at:Date
                   )

