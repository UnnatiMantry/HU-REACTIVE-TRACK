package com.hu.reactivetrack.repository

import com.hu.reactivetrack.models.User
import org.springframework.data.mongodb.repository.ReactiveMongoRepository
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono

interface userRepository : ReactiveMongoRepository <User, String>{
    fun findBystatus(name: Mono<String>): Flux<User>
    fun findByid(id : Int) : Flux<User>
}