package com.hu.reactivetrack.models.wrappers

import com.hu.reactivetrack.models.User

data class WrapperToUserClass(val code:Int,
                              val meta:Any,
                              val data:ArrayList<User>
                              )
