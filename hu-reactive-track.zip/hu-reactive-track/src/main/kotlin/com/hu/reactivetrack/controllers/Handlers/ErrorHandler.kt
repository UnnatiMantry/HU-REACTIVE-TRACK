package com.hu.reactivetrack.controllers.Handlers

import com.hu.reactivetrack.GoRestErrorResponse
import com.hu.reactivetrack.exceptions.BadDataException
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.ControllerAdvice
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.ResponseBody
import org.springframework.web.bind.annotation.ResponseStatus

@ControllerAdvice
class ErrorHandler {
    @ExceptionHandler(BadDataException::class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    @ResponseBody
    fun invalidWebInput(e : BadDataException): GoRestErrorResponse{
        return GoRestErrorResponse(e.statusCode,e.errors)
    }
}