package com.hu.reactivetrack.models.wrappers

data class CommentRequest (val post_id:Int,
                            val name:String,
                            val email: String,
                            val body: String )