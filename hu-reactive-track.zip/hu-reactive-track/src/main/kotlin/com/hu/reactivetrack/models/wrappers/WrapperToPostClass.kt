package com.hu.reactivetrack.models.wrappers

import com.hu.reactivetrack.models.Post

data class WrapperToPostClass(val code:Int,
                              val meta:Any,
                              val data:ArrayList<Post>
                              )
