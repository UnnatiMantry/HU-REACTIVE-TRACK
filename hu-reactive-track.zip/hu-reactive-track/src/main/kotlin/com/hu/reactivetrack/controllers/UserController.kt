package com.hu.reactivetrack.controllers

import com.hu.reactivetrack.models.User
import com.hu.reactivetrack.models.wrappers.CreateUser
import com.hu.reactivetrack.service.UserService
import org.springframework.web.bind.annotation.*
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono

@RestController
class UserController (val userService: UserService){

    @PostMapping("/main/user")
    fun createUser(@RequestBody createUser: CreateUser): Mono<User> {
        return userService.createUser(createUser)
    }

    @GetMapping("/main/getUsers")
    fun getUsers() : Flux<User>{
        return userService.getActiveUsers()
    }

    @GetMapping("/main/allPostUser/{userid}")
    fun allPostUser(@PathVariable userid : Int) : Flux<Any>{
        return userService.allPostUser(userid)
    }
}