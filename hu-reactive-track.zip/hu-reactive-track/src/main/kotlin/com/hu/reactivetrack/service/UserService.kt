package com.hu.reactivetrack.service

import com.hu.reactivetrack.GoRest.GoRestGateway
import com.hu.reactivetrack.models.User
import com.hu.reactivetrack.models.wrappers.CreateUser
import com.hu.reactivetrack.repository.postRepository
import com.hu.reactivetrack.repository.userRepository
import org.springframework.stereotype.Service
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono

@Service
class UserService(val userRepository: userRepository, val goRestGateway: GoRestGateway, val postRepository : postRepository){

    fun createUser(createUser: CreateUser):Mono<User>{
        return goRestGateway.createUser(createUser)
            .flatMap { userRepository.save(it) }
    }

    fun getActiveUsers() :Flux <User>{
        return userRepository.findBystatus(Mono.just("Active"))
    }

    fun allPostUser(usedid : Int) :Flux<Any>{
        return Flux.concat(postRepository.findByuserId(usedid),userRepository.findByid(usedid))
    }

}