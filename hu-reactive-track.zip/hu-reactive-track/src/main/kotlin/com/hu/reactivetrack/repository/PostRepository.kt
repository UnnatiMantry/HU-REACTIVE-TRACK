package com.hu.reactivetrack.repository

import com.hu.reactivetrack.models.Post
import org.springframework.data.mongodb.repository.Query
import org.springframework.data.mongodb.repository.ReactiveMongoRepository
import reactor.core.publisher.Flux

interface postRepository : ReactiveMongoRepository<Post, String> {
    @Query("{ 'user_id': ?0}")
    fun findByuserId(user_id:Int): Flux<Post>
    fun findByid(id : Int) : Flux<Post>

}