package com.hu.reactivetrack.controllers

import com.hu.reactivetrack.models.wrappers.*
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.web.bind.annotation.*
import org.springframework.web.bind.annotation.RestController
import org.springframework.web.reactive.function.client.WebClient
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono

@RestController
class GoRestController {

    private val log: Logger =  LoggerFactory.getLogger(GoRestController::class.java)

    var webClient = WebClient.create("https://gorest.co.in/public-api")

    @GetMapping("/user/all")
    fun getAllUsers(): Flux<WrapperToUserClass> {
        return webClient.get().uri("/users").retrieve()
            .bodyToFlux(WrapperToUserClass::class.java).log("users in gorest api").log()
    }

    @GetMapping("/posts/all")
    fun getAllPosts(): Flux<WrapperToPostClass> {
        return webClient.get().uri("/posts").retrieve()
            .bodyToFlux(WrapperToPostClass::class.java).log("users in gorest api")
    }

    @GetMapping("/comments/all")
    fun getAllComments(): Flux<WrapperToCommentClass> {
        return webClient.get().uri("/comments").retrieve()
            .bodyToFlux(WrapperToCommentClass::class.java).log("users in gorest api")
    }


    @GetMapping("/go/user/get/{id}")
    fun getUserDetails(@PathVariable id: Int): Mono<CreateUserResponse> {
        return webClient.get().uri("/users/{id}", id)
            //.header("Authorization", authToken)
            .headers { h -> h.setBearerAuth("fbaef4334fd3a5d400771a14aa7d19cfb4a2176be6e267e7adc763703b7a508f") }
            .retrieve()
            .bodyToMono(CreateUserResponse::class.java).log("get user based on id$id")
    }

    @PostMapping("/go/user/posts/{id}")
    fun createUserPost(@PathVariable id: Int, @RequestBody post:CreateUserPost):Mono<CreateUserPostResponse>{

        log.info("create user post with userid $id")

        val postMono = Mono.just(post)
        return webClient.post().uri("/users/{id}/posts",id).contentType(MediaType.APPLICATION_JSON)
            //.header("Authorization", authToken)
            .headers { h -> h.setBearerAuth("fbaef4334fd3a5d400771a14aa7d19cfb4a2176be6e267e7adc763703b7a508f") }
            .accept(MediaType.APPLICATION_JSON)
            .body(postMono, CreateUserPost::class.java).exchangeToMono { response ->
                if (response.statusCode().equals(HttpStatus.OK)) {
                    log.info("status is ok")
                    response.bodyToMono(CreateUserPostResponse::class.java)
                } else {
                    log.info("inside else")
                    null
                }
            }
    }
}