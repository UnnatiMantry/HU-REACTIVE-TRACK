package com.hu.reactivetrack.service

import com.hu.reactivetrack.GoRest.GoRestGateway
import com.hu.reactivetrack.models.Post
import com.hu.reactivetrack.models.wrappers.PostRequest
import com.hu.reactivetrack.repository.commentRepository
import com.hu.reactivetrack.repository.postRepository
import org.springframework.stereotype.Service
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono

@Service
class PostService(val postRepository: postRepository,
                  val commentRepository: commentRepository ,
                  val goRestGateway: GoRestGateway){

    fun createPost(postRequest: PostRequest):Mono<Post>{
        return goRestGateway.createPost(postRequest)
            .flatMap { postRepository.save(it) }
    }

    fun getAllCommentsOnPost(postId : Int) : Flux<Any> {
        return Flux.concat(commentRepository.findAllCommentByPostId(postId),postRepository.findByid(postId))
    }
}