package com.hu.reactivetrack.models.wrappers

data class PostRequest(val user_id: Int,
                       val title: String,
                       val body: String)
