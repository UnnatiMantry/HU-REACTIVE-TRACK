package com.hu.reactivetrack.models.wrappers

data class CreateUserPost(val title:String,
                            val body:String)
