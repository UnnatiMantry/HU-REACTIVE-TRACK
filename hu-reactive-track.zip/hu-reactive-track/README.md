# Reactive Track

### Following are the dependencies:

1. Kotlin
2. Spring Web Reactive

### Pre-requisites

1. Install Java 11
2. Install gradle 

### Build
`./gradlew build`
### Test
`./gradlew test`

### MongoDB client
Robo 3T 




